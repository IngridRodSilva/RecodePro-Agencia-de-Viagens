﻿using AgenciaDeViagens.Models;
using AgenciaDeViagens.Data;
using AgenciaDeViagens.Enum;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System;

namespace AgenciaDeViagens.Controllers
{
    public class ClienteController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            var dbcontext = new Contexto();

            ViewData["clientes"] = dbcontext.Clientes.Where(p => p.Id > 0).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Index(Cliente cliente)
        {
            var dbcontext = new Contexto();
            dbcontext.Add(cliente);
            dbcontext.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpPost ("cliente.Id")]
        public IActionResult Deletar(Cliente cliente)
        {
            var dbcontext = new Contexto();

            var clienteDeletar = dbcontext.Clientes.Find(cliente.Id); //Recebe parâmetro de procura do ID para que no formulário, o usuário o busque pelo índice
            dbcontext.Remove(clienteDeletar); //método de remoção 
            dbcontext.SaveChanges(); //Salvar alterações

            return RedirectToAction("Index");
        }


        [HttpPost] // Enviar/postar
        public IActionResult Atualizar(Cliente clienteNewDados)
        {
            var dbcontext = new Contexto();

            var clienteDados = dbcontext.Clientes.Find(clienteNewDados.Id);

            clienteDados.Nome = clienteNewDados.Nome;
            clienteDados.CPF = clienteNewDados.CPF;
            clienteDados.RG = clienteNewDados.RG;
            clienteDados.TelefoneCelular = clienteNewDados.TelefoneCelular;
            clienteDados.Endereco = clienteNewDados.Endereco;
            clienteDados.DataNascimento = clienteNewDados.DataNascimento;
            clienteDados.Situacao = clienteNewDados.Situacao;

            dbcontext.SaveChanges();

            return RedirectToAction("Index");
        }

       
        
    }
}