﻿using AgenciaDeViagens.Models;
using Microsoft.EntityFrameworkCore;

namespace AgenciaDeViagens.Data
{
    //A classe contexto é a responsável por integrar e "manipular" os dados na tabela 
    public class Contexto : DbContext 
    {
        //Propriedade (Clientes) onde se realiza as operações
        public DbSet<Cliente> Clientes { get; set; }

        //Opções de criação -> "OptionsBuildes=objeto, usado como parâmetro para a conexão
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //String de conexão -> DataSource: Nome do banco (A contra barra dupla serve para que a ide reconheça o banco);
            //Initial Catalog: tabela a ser criada; Integrated Security (Segurança Integrada): A forma como se conecta ao banco, neste caso, pelo windows (sem login e senha).
            optionsBuilder.UseSqlServer("Data Source=CS\\SQLSERVER; Initial Catalog = Agencia de Viagens; Integrated Security=True");
        }

        //método protegido e vazio que têm como parâmetro a classe "ModelBuilder" junto com Objeto "modelBuilder"
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Método que busca qual entidade mapear no Banco de dados. A expressão "lambda: =>" determina qual o nome o elemento seguinte receberá
            modelBuilder.Entity<Cliente>(table =>
           {
                //Dentro da entidade Cliente, a tabela receberá nome "Clientes" através da função lambda.
                //Assim como a determinação da chave primária, com a propriedade "HasKey" ou "tem chave" 
                table.ToTable("Clientes");
                table.HasKey(prop => prop.Id);



               //Declaração dos demais elementos da tabela

               table.Property(prop => prop.Nome).HasMaxLength(40).IsRequired();
                //"Tem tamanho máximo" -> Característica que recebe agora quant. máxima de 40 caracteres. "É requerido" -> Determina que o campo não pode ser nulo. 

                table.Property(prop => prop.CPF).HasColumnType("varchar(11)").IsRequired();
               //Diferente do anterior, agora especificamos qual tipo de dado o campo receberá, no primeiro estava implícito que era string.

               table.Property(prop => prop.RG).HasColumnType("varchar(9)").IsRequired();
               table.Property(prop => prop.TelefoneCelular).HasColumnType("varchar(11)").IsRequired();
               table.Property(prop => prop.Endereco).HasColumnType("varchar(50)").IsRequired();
               table.Property(prop => prop.DataNascimento).HasColumnType("date").IsRequired();


               //No caso do Enum, podemos declarar dos dois jeitos: índice ou seu conteúdo. Neste caso, optamos pelo conteúdo, então convertemos para string e declaramos um número máximo para controle.
               //Ademais, denotaos que é possivel encadear diversos métodos em uma só linha
               table.Property(prop => prop.Situacao).HasConversion<string>().HasMaxLength(9).IsRequired();
           });
        }
    }
}
