﻿namespace AgenciaDeViagens.Enum
{
// Enumerator = enumerador que apresenta determinado número de opções de escolha para o usuário.
    public enum Situacao
    {
        Ativo,
        Inativo,
        Bloqueado
    }
}
