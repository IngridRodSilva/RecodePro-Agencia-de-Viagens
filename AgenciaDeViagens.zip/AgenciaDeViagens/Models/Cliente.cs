﻿using AgenciaDeViagens.Enum;
using System;

namespace AgenciaDeViagens.Models
{
    public class Cliente
    {
        //Toda tabela necessita de uma chave primária, sendo esta o "Id" (também representado no modelo conceitual)    
        public int Id { get; set; }
        public string Nome { get; set; }
        public string CPF { get; set; }
        public string RG { get; set; }
        public string TelefoneCelular { get; set; }
        public string Endereco { get; set; }

        // Para parar de dar erro em "Enum" e "DateTime", basta fazer uma importação (assim como importavámos a entrada de dados/teclado do usuário em Java)
        public DateTime DataNascimento { get; set; }
        public Situacao Situacao { get; set; }
    }
}
